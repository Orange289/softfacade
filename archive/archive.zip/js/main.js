var PAGE_SETTINGS = {
	css: {
		activeClass: 'is-active',
		hiddenClass: 'is-hidden',
		openedClass: 'is-opened',
		headerHiddenClass: 'header--hidden',
		headerFixedClass: 'header--fixed'
	}
};

$(function () {
	var $window = $(window);
	var $header = $('header');
	var headerHeight = parseInt($header.height());

	$('main').css('display', 'block');

	// Sticky header

	var bindEffects = function () {
		var scrolled = $window.scrollTop();
		if (scrolled > headerHeight && scrolled < (headerHeight * 2)) {
			$header.addClass(PAGE_SETTINGS.css.headerHiddenClass);
		} else {
			$header
				.removeClass(PAGE_SETTINGS.css.headerHiddenClass)
				.removeClass(PAGE_SETTINGS.css.headerFixedClass);
		}

		if (scrolled > (headerHeight * 2)) {
			$header
				.removeClass(PAGE_SETTINGS.css.headerHiddenClass)
				.addClass(PAGE_SETTINGS.css.headerFixedClass);
		}
	};

	$window.on('scroll', bindEffects);


	// Menu toggle

	$('[data-toggle-menu]').click(function () {
		$(this).toggleClass(PAGE_SETTINGS.css.activeClass);
		$('[data-menu]').slideToggle();
		$header.toggleClass(PAGE_SETTINGS.css.openedClass);
	});

	// Slick slider options

	$('.slick').slick({
		dots: false,
		infinite: true,
		speed: 300,
		slidesToShow: 7,
		slidesToScroll: 7,
		responsive: [
			{
				breakpoint: 1200,
				settings: {
					slidesToShow: 4,
					slidesToScroll: 4
				}
			},
			{
				breakpoint: 1024,
				settings: {
					slidesToShow: 2,
					slidesToScroll: 2
				}
			},
			{
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1
				}
			}
		]
	});

	// Toggle active slider item

	$('.slider__item').click(function () {
		$(this)
			.addClass(PAGE_SETTINGS.css.activeClass)
			.siblings()
			.removeClass(PAGE_SETTINGS.css.activeClass);
	})

	// Tabs

	$('.tabs__link').click(function (e) {
		e.preventDefault();
		var $link = $(this);
		var tabIndex = $link.index();
		var $tab = $link
			.parents('.tabs')
			.find('.tab')
			.eq(tabIndex);
		$link
			.addClass(PAGE_SETTINGS.css.activeClass)
			.siblings()
			.removeClass(PAGE_SETTINGS.css.activeClass);
		$tab
			.removeClass(PAGE_SETTINGS.css.hiddenClass)
			.siblings('.tab')
			.addClass(PAGE_SETTINGS.css.hiddenClass);
	});



})